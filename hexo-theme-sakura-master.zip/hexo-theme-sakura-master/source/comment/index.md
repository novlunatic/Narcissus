---
title: comment
date: 2021-07-13
keywords: 留言板
description: 
comments: true
photos: https://cdn.jsdelivr.net/gh/honjun/cdn@1.4/img/banner/comment.jpg
---
{% raw %}
<div class="entry-content">
  <div class="poem-wrap">
    <div class="poem-border poem-left">
    </div>
    <div class="poem-border poem-right">
    </div>
    <h1>
    念两句诗</h1>
    <p id="poem">
    离宫散萤天似水，竹黄池冷芙蓉死。</p>
    <p id="info">
    李商隐</p>
  </div>
</div>
{% endraw %}
